#!/bin/bash
set -Eeuo pipefail
