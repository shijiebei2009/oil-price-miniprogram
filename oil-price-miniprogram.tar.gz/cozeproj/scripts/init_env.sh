#!/bin/bash

cd "${COZE_WORKSPACE_PATH}"

echo "✅ 初始化完成"
